//引导模块
angular.module('costApp',[
    "ng","costControllers","costDirectives","costServices","costFilters","ui.bootstrap"
])
